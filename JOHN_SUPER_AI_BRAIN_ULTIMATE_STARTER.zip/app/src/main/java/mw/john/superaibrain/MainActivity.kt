package mw.john.superaibrain

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF071426)
private val Blue = Color(0xFF168BFF)
private val Panel = Color(0xFF10243D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BrainHome(networkStatus(this)) }
    }
}

private fun networkStatus(context: Context): String {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val network = cm.activeNetwork ?: return "Palibe network yolumikizidwa"
    val caps = cm.getNetworkCapabilities(network) ?: return "Network status siyikupezeka"
    return when {
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi yolumikizidwa"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data yolumikizidwa"
        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet yolumikizidwa"
        else -> "Network ina yolumikizidwa"
    }
}

@Composable
fun BrainHome(network: String) {
    var prompt by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("Sankhani AI provider kuti muyambe. API integration idzawonjezedwa motetezeka.") }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Blue,
        background = Navy,
        surface = Panel
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("JOHN SUPER", color = Blue, fontSize = 30.sp)
                    Text("AI BRAIN • ULTIMATE", color = Color.White, fontSize = 18.sp)
                    Text("Your multi-AI control centre", color = Color.LightGray)
                }
                item { InfoCard("NETWORK STATUS", network) }
                item {
                    Text("MASTER ALL AI", color = Blue, fontSize = 20.sp)
                    listOf("ChatGPT", "Google Gemini", "Claude", "DeepSeek", "Other AI providers").forEach {
                        InfoCard(it, "Integration slot — API key and provider setup required")
                    }
                }
                item {
                    Text("AI ASSISTANT", color = Blue, fontSize = 20.sp)
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        label = { Text("Lembani funso lanu") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                    Button(
                        onClick = { answer = if (prompt.isBlank()) "Chonde lembani funso." else "UI yokonzeka. Kuti AI iyankhe, tifunika kulumikiza provider API motetezeka." },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("SEND TO AI") }
                    InfoCard("RESPONSE", answer)
                }
                item {
                    Text("MASTER ALL NETWORK", color = Blue, fontSize = 20.sp)
                    InfoCard("Network tools", "Connection status • Wi-Fi/mobile overview • diagnostics")
                    Text(
                        "Zida zosinthira network zimadalira zilolezo za Android ndi network operator.",
                        color = Color.LightGray
                    )
                }
                item {
                    Text("SECURITY NOTE", color = Blue, fontSize = 18.sp)
                    Text("Sungani API keys mwachinsinsi. Musaziike mu GitHub public repository.", color = Color.White)
                }
            }
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Blue, fontSize = 16.sp)
            Spacer(Modifier.height(5.dp))
            Text(body, color = Color.White)
        }
    }
}
